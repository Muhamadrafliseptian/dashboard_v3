<footer>
    <div class="pull-right">
        Copyright &copy; 2024. All Rights Reserved. Project Dibuat Oleh
        <a href="https://github.com/Teguhriyadi?tab=repositories">
            Anonymus
        </a>
    </div>
    <div class="clearfix"></div>
</footer>
