<script src="{{ url('public/template/vendors/jquery/dist/jquery.min.js') }}"></script>
<script src="{{ url('public/template/vendors/bootstrap/dist/js/bootstrap.min.js') }}"></script>
<script src="{{ url('public/template/vendors/fastclick/lib/fastclick.js') }}"></script>
<script src="{{ url('public/template/vendors/nprogress/nprogress.js') }}"></script>
<script src="{{ url('public/template/build/js/custom.min.js') }}"></script>
