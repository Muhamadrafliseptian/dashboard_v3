<link href="{{ url('public/template/vendors/bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ url('public/template/vendors/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
<link href="{{ url('public/template/vendors/nprogress/nprogress.css') }}" rel="stylesheet">
<link href="{{ url('public/template/build/css/custom.min.css') }}" rel="stylesheet">
